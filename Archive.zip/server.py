from flask import Flask, redirect, render_template, request, url_for
from user import User

app = Flask(__name__)

@app.route('/')
def read():
    users = User.read_users()
    return render_template('read.html', users=users)

@app.route('/new')
def new():
    return render_template('create.html')

@app.route('/create', methods =['POST'])
def create():
    User.create_user(request.form)
    print(request.form)
    return redirect(url_for('read'))

@app.route('/edit/<int:user_id>')
def edit(user_id):
    user = User.get_one_user(user_id)
    return render_template('edit.html', user=user)

@app.route('/update/<int:user_id>', methods = ['POST'])
def update(user_id):
    data = {
        "id": user_id,
        "first_name": request.form["first_name"],
        'last_name': request.form['last_name'],
        'email': request.form['email']
    }
    user = User.update_user(user_id)
    return redirect(url_for('readone'))

@app.route('/read_one/<int:user_id>')
def read_one(user_id):
    print(user_id)
    userobject = User.get_one_user(user_id)
    return render_template('readone.html', user = userobject)

@app.route('/delete_one/<int:user_id>')
def delete_one(user_id):
    user = User.delete_user(user_id)
    return redirect('/')

if __name__ =="__main__":
    app.run(debug=True, port=5001)
