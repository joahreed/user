from mySQLconnection import connectToMySQL

class User: 
    DB = 'users_assignment_db'
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    
    
    @classmethod
    def read_users(cls):
        query = 'select * from users'
        results = connectToMySQL(cls.DB).query_db(query)
        print(results)
        users = []
        for row in results:
            user = User(row)
            users.append(user)
        return users


    @classmethod
    def create_user(cls, data):
        query = """INSERT INTO users (first_name,last_name,email)
    	VALUES (%(first_name)s,%(last_name)s,%(email)s);"""
        result = connectToMySQL(cls.DB).query_db(query, data)
        return result

    @classmethod
    def get_one_user(cls, user_id):
        query = 'select * from users where id = %(id)s'
        data = {'id' : user_id}
        results = connectToMySQL(cls.DB).query_db(query, data)
        return results[0]

    @classmethod
    def updated_user(cls, data):
        query = """UPDATE users 
                SET first_name=%(first_name)s,last_name=%(last_name)s,email=%(email)s
                WHERE id = %(id)s;"""
        return connectToMySQL(cls.DB).query_db(query,data)

    @classmethod
    def delete_user(cls, user_id):
        query = 'delete from users where id = %(id)s'
        data = {'id' : user_id}
        return connectToMySQL(cls.DB).query_db(query, data)
